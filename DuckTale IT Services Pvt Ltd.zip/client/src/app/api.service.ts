// gaurav
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable, Subject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class ApiService {
    public serviceBase = environment.API_URL;
    public headers = new HttpHeaders({
        'Content-Type': 'application/json'
    });
    public loadingShow: boolean = false;
    constructor(
        private router: Router,
        private http: HttpClient,
       ) {

    }
   



    get(url: string) {
        console.log(localStorage.getItem('user'),'forbackend');
        
        return this.http.get(this.serviceBase + url, { headers: this.headers });
    }
    post(url: string, data: any) {

        return this.http.post(this.serviceBase + url, data, { headers: this.headers });
    }

}