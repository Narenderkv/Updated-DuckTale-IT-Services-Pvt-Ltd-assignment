export const environment = {
  production: true,
 

   api_url: 'http://localhost:8999/',
   leadsquared_api_url : '',
};
